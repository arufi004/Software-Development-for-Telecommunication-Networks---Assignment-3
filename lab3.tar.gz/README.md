Name:			Anthony Rufin
Panther ID		6227314

Class:			TCN5440
Section:		U01
Semester:		Spring 2025

Assignment		Programming Assignment 3
Due:			April 24, 2025

Video Recording link:  https://youtu.be/EOxxA9M8GIY 

Honesty Statement: 	I have done this assignment completely on my own. I have not copied it, nor have I given my solution to anyone else. 
			I understand that if I am involved in plagiarism or cheating I will receive the penalty specified in the FIU regulations. 
